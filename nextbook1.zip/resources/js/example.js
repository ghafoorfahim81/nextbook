export default 'ES6 Modules are working!';
