<?php

namespace Database\Seeders;

use App\Models\Administration\Department;
use App\Models\User;
// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Str;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        User::create([
            'id' => Str::uuid(),
            'name' => 'admin',
            'email' => 'admin@gmail.com',
            'password' => bcrypt('password'),

        ]);
<<<<<<< HEAD

        Department::factory()->count(5)->create();
=======
        // $this->call(ControlPanel\DesignationSeeder::class);
>>>>>>> faae6c0f72180eab0724e7f3dc3769c906b2c1de
    }
}
