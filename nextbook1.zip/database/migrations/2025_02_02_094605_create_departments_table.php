<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::disableForeignKeyConstraints();

        Schema::create('departments', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->string('name')->unique();
            $table->text('remark')->nullable();
<<<<<<< HEAD
            $table->uuid('parent_id')->nullable();
            $table->uuid('created_by');
            $table->uuid('updated_by')->nullable();

=======
            $table->foreignUuid('parent_id')->nullable()->constrained('departments', 'id');
            $table->foreignUuid('created_by')->constrained('users');
            $table->foreignUuid('updated_by')->nullable()->constrained('users');
>>>>>>> faae6c0f72180eab0724e7f3dc3769c906b2c1de
            $table->timestamps();
        });

        Schema::enableForeignKeyConstraints();

        Schema::table('departments', function (Blueprint $table) {
            $table->foreign('parent_id')
                ->references('id')
                ->on('departments')
                ->onDelete('CASCADE');

            $table->foreign('created_by')->references('id')->on('users');
            $table->foreign('updated_by')->references('id')->on('users');
        });
    }


    public function down(): void
    {
        Schema::dropIfExists('departments');
    }
};
